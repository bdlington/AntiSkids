#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <tchar.h>
#include <string>
#include <vector>
#include <algorithm>
#include <thread>
#include <chrono>
#include <winternl.h>
#include <ntstatus.h>
#include <intrin.h>
#include <iphlpapi.h>

#pragma comment(lib, "Advapi32.lib")
#pragma comment(lib, "User32.lib")
#pragma comment(lib, "Psapi.lib")
#pragma comment(lib, "iphlpapi.lib")


bool g_TestMode = false;

void DebugLog(const std::wstring& msg) {
    if (g_TestMode) {
        wprintf(L"[DEBUG] %s\n", msg.c_str());
        OutputDebugStringW((L"[#StopSkids] " + msg + L"\n").c_str());
    }
}

std::wstring ConvertToWString(const char* str) {
    if (!str) return L"";

    size_t len = strlen(str);
    std::wstring wstr(len + 1, L'\0'); 

    size_t converted = 0;
    errno_t err = mbstowcs_s(&converted, &wstr[0], wstr.size(), str, _TRUNCATE);

    if (err != 0) {
        return L"(conversion failed)";
    }

    wstr.resize(converted - 1); 
    return wstr;
}


std::wstring ToLower(const std::wstring& s) {
    std::wstring out = s;
    std::transform(out.begin(), out.end(), out.begin(), ::towlower);
    return out;
}

bool CheckVMCPUID_Internal();



bool CheckVMWareRegistry() {
    HKEY hKey;
    const wchar_t* vmKeys[] = {
        L"SOFTWARE\\VMware, Inc.\\VMware Tools",
        L"SOFTWARE\\Oracle\\VirtualBox Guest Additions"
    };

    for (auto key : vmKeys) {
        DebugLog(L"Checking registry key: " + std::wstring(key));
        if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, key, 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
            RegCloseKey(hKey);
            DebugLog(L"Detected VM key in registry: " + std::wstring(key));
            return true;
        }
    }
    return false;
}


bool CheckVMWareFiles() {
    const wchar_t* vmFiles[] = {
        L"C:\\Windows\\System32\\drivers\\vmmouse.sys",
        L"C:\\Windows\\System32\\drivers\\vmhgfs.sys",
        L"C:\\Windows\\System32\\drivers\\VBoxMouse.sys",
        L"C:\\Windows\\System32\\drivers\\VBoxGuest.sys",
        L"C:\\Windows\\System32\\vboxdisp.dll",
        L"C:\\Windows\\System32\\vmGuestLib.dll"
    };

    int vmFileCount = 0;
    for (auto file : vmFiles) {
        DebugLog(L"Checking file existence: " + std::wstring(file));
        if (GetFileAttributesW(file) != INVALID_FILE_ATTRIBUTES) {
            DebugLog(L"Detected VM-related file: " + std::wstring(file));
            vmFileCount++;
        }
    }
    return vmFileCount >= 2;
}


bool CheckVMWareMAC() {
    DebugLog(L"Checking MAC address for VM prefixes...");
    IP_ADAPTER_INFO* pAdapterInfo = nullptr;
    ULONG ulOutBufLen = 0;

    if (GetAdaptersInfo(nullptr, &ulOutBufLen) == ERROR_BUFFER_OVERFLOW) {
        pAdapterInfo = (IP_ADAPTER_INFO*)malloc(ulOutBufLen);
        if (GetAdaptersInfo(pAdapterInfo, &ulOutBufLen) == NO_ERROR) {
            int vmMacCount = 0;
            for (auto pAdapter = pAdapterInfo; pAdapter; pAdapter = pAdapter->Next) {
                if (pAdapter->Type != MIB_IF_TYPE_ETHERNET) continue;

                if (pAdapter->AddressLength == 6) {
                    BYTE* mac = pAdapter->Address;

                    if ((mac[0] == 0x00 && mac[1] == 0x05 && mac[2] == 0x69) ||
                        (mac[0] == 0x00 && mac[1] == 0x0C && mac[2] == 0x29) ||
                        (mac[0] == 0x00 && mac[1] == 0x1C && mac[2] == 0x14) ||
                        (mac[0] == 0x00 && mac[1] == 0x50 && mac[2] == 0x56) ||
                        (mac[0] == 0x08 && mac[1] == 0x00 && mac[2] == 0x27)) {
                        DebugLog(L"Detected VM MAC address on adapter: " + std::wstring(pAdapter->Description, pAdapter->Description + strlen(pAdapter->Description)));
                        vmMacCount++;
                    }
                }
            }
            free(pAdapterInfo);
            return vmMacCount > 0;
        }
        free(pAdapterInfo);
    }
    return false;
}


bool CheckVMCPUID() {
    return CheckVMCPUID_Internal();
}

bool CheckVMCPUID_Internal() {
    __try {
        int cpuInfo[4];
        char vendor[13] = { 0 };

        __cpuid(cpuInfo, 0);
        *((int*)vendor) = cpuInfo[1];
        *((int*)(vendor + 4)) = cpuInfo[3];
        *((int*)(vendor + 8)) = cpuInfo[2];
        for (int i = 0; i < 12; i++) {
            if (vendor[i] >= 'A' && vendor[i] <= 'Z') {
                vendor[i] = vendor[i] + 32;
            }
        }

        if (strstr(vendor, "microsoft hv") ||
            strstr(vendor, "vmwarevmware") ||
            strstr(vendor, "prl hyperv")) {
            return true;
        }

        __cpuid(cpuInfo, 1);
        bool hypervisorBit = (cpuInfo[2] & (1 << 31)) != 0;

        if (hypervisorBit) {
            __cpuid(cpuInfo, 0x40000000);
            if (cpuInfo[0] >= 0x40000000) {
                char hvVendor[13] = { 0 };
                *((int*)hvVendor) = cpuInfo[1];
                *((int*)(hvVendor + 4)) = cpuInfo[2];
                *((int*)(hvVendor + 8)) = cpuInfo[3];
                return (strstr(hvVendor, "VMwareVMware") ||
                    strstr(hvVendor, "Microsoft Hv") ||
                    strstr(hvVendor, "KVMKVMKVM") ||
                    strstr(hvVendor, "VBoxVBoxVBox"));
            }
        }

        return false;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

bool CheckVMTiming() {
    DebugLog(L"Checking for VM via Sleep timing anomalies...");
    int slowSamples = 0;
    const int totalSamples = 3;

    for (int i = 0; i < totalSamples; i++) {
        auto start = std::chrono::high_resolution_clock::now();
        Sleep(50);
        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
        DebugLog(L"Sleep duration sample " + std::to_wstring(i) + L": " + std::to_wstring(duration.count()) + L"ms");
        if (duration.count() > 100) slowSamples++;
        Sleep(10);
    }
    return slowSamples >= 2;
}


bool CheckVirtualMachine() {
    int vmScore = 0;

    if (CheckVMWareRegistry()) { DebugLog(L"VMWare Registry Detected"); vmScore += 3; }
    if (CheckVMWareFiles()) { DebugLog(L"VMWare Files Detected");    vmScore += 2; }
    if (CheckVMWareMAC()) { DebugLog(L"VMWare MAC Detected");      vmScore += 2; }
    if (CheckVMCPUID()) { DebugLog(L"VM CPUID Detected");        vmScore += 1; }
    if (CheckVMTiming()) { DebugLog(L"VM Timing Detected");       vmScore += 1; }


    if (g_TestMode) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32W pe = { sizeof(pe) };
            if (Process32FirstW(snap, &pe)) {
                do {
                    std::wstring name = ToLower(pe.szExeFile);
                    if (name == L"code.exe") {
                        DebugLog(L"Visual Studio Code detected (code.exe) - adding 5 to VM score (test mode only)");
                        vmScore += 5;
                        break;
                    }
                } while (Process32NextW(snap, &pe));
            }
            CloseHandle(snap);
        }
    }

    if (g_TestMode) {
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        CONSOLE_SCREEN_BUFFER_INFO csbi;
        WORD oldColor = 0;
        if (hConsole != INVALID_HANDLE_VALUE && GetConsoleScreenBufferInfo(hConsole, &csbi)) {
            oldColor = csbi.wAttributes;
            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        }
        wprintf(L"[DEBUG] VM Score: %d\n", vmScore);
        if (hConsole != INVALID_HANDLE_VALUE && oldColor)
            SetConsoleTextAttribute(hConsole, oldColor);
    } else {
        DebugLog(L"[DEBUG] VM Score: " + std::to_wstring(vmScore));
    }
    return vmScore >= 3;
}



bool CheckHardwareBreakpoints() {
    CONTEXT ctx = {};
    ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    HANDLE hThread = GetCurrentThread();

    if (GetThreadContext(hThread, &ctx)) {
        return (ctx.Dr0 != 0 || ctx.Dr1 != 0 || ctx.Dr2 != 0 || ctx.Dr3 != 0);
    }
    return false;
}


bool CheckExecutionTiming() {
    int slowSamples = 0;
    const int totalSamples = 5;

    for (int i = 0; i < totalSamples; i++) {
        auto start = std::chrono::high_resolution_clock::now();

        volatile int result = 0;
        for (int j = 0; j < 500; ++j) {  
            result += j * 2;
        }

        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);

        if (duration.count() > 50000) {
            slowSamples++;
        }
    }
    return slowSamples >= totalSamples;
}


bool CheckBasicDebugging() {
    if (IsDebuggerPresent()) return true;
    BOOL remote = FALSE;
    CheckRemoteDebuggerPresent(GetCurrentProcess(), &remote);
    return remote == TRUE;
}

bool CheckNtQueryInfo() {
    using NtQIP = NTSTATUS(WINAPI*)(HANDLE, UINT, PVOID, ULONG, PULONG);
    HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
    if (!hNtdll) return false;
    auto fn = (NtQIP)GetProcAddress(hNtdll, "NtQueryInformationProcess");
    if (!fn) return false;

    DWORD present = 0;
    if (NT_SUCCESS(fn(GetCurrentProcess(), 7, &present, sizeof(present), nullptr)))
        return present != 0;
    return false;
}

bool CheckOutputDebugString() {
    SetLastError(0);
    OutputDebugStringA("SysNetHostTest");
    return GetLastError() != 0;
}

void ShowFakeCrashMessage(const std::wstring& toolName) {
	// add on ur own custom messages here such as "Please dont attempt to Debug"
}



void ScanAndKillProcesses() {  
    static const std::vector<std::wstring> tools = {
    // Debuggers
    L"x64dbg", L"x32dbg", L"ollydbg", L"windbg", 
    L"immunitydebugger", L"kdbg", L"bugdbg", L"devenv",
    L"gdb", L"lldb", L"radare2", L"rr", L"winice",
    L"turbodebug", L"softice", L"hxd", L"hiew",
    
    // Memory/Process Tools
    L"cheatengine", L"artmoney", L"tsearch", L"gameconqueror",
    L"scyllahide", L"processhacker", L"systeminformer", 
    L"procexp", L"procmon", L"vmmap", L"rammap",
    L"hollowshunter", L"pe-sieve", L"processexplorer",
    
    // RE Frameworks
    L"frida", L"angr", L"qira", L"panorama",
    L"bochs", L"qemu", L"unicorn", L"flare-vm",
    
    // Binary Analysis
    L"ida", L"ghidra", L"binaryninja", L"hopper",
    L"cutter", L"rizin", L"ilspy", L"dnspy",
    L"dotpeek", L"ilspycmd", L"peid", L"pe-bear",
    L"detect it easy", L"die", L"pestudio", 
    L"cff explorer", L"stud_pe", L"lordpe",
    
    // Network Tools
    L"wireshark", L"fiddler", L"burpsuite", 
    L"charles", L"mitmproxy", L"tcpdump",
    L"prozilla", L"ollydbg", L"httpdebugger",
    
    // Other Analysis Tools
    L"apimonitor", L"api monitor", L"regshot", 
    L"dependencies", L"dumpbin", L"bindiff",
    L"jadx", L"jd-gui", L"recaf", L"bytecode-viewer",
    L"androguard", L"jeb", L"gda", L"androidkiller",
    
    // Virtualization/Sandbox
    L"vmware", L"virtualbox", L"qemu", L"xen",
    L"hyper-v", L"parallels", L"wine", L"bochs",
    
    // Packer/Unpacker Tools
    L"upx", L"mew", L"aspack", L"fsg",
    L"pecompact", L"petite", L"upack", L"mpress",
    
    // .NET Specific
    L"ilspy", L"dnspy", L"de4dot", L"dotpeek",
    L"ilspycmd", L"justdecompile", L"reflector",
    
    // Kernel Debuggers
    L"kdb", L"kd", L"winDbg", L"verifier",
    
    // Scriptable Debuggers
    L"pydbg", L"voltron", L"pai mei",
    
    // Mobile Debuggers
    L"adb", L"lldb-android", L"jdb", L"cycript",
    
    // niche tools
    L"cutter", L"binary ninja", L"rizin", L"bochs",
    L"pe-sieve", L"hollowshunter", L"scylla", L"x64dbg"
}; 

    DebugLog(L"Scanning for suspicious processes...");  

    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);  
    if (snap == INVALID_HANDLE_VALUE) return;  

    PROCESSENTRY32W pe = { sizeof(pe) };  
    bool found = false;
    if (Process32FirstW(snap, &pe)) {  
        do {  
            std::wstring name = ToLower(pe.szExeFile);  
            for (auto& t : tools) {  
                if (name.find(t) != std::wstring::npos) {  
                    found = true;
                    HANDLE hProc = OpenProcess(PROCESS_TERMINATE, FALSE, pe.th32ProcessID);  
                    if (hProc) {  
                        TerminateProcess(hProc, 1);   
                        if (g_TestMode) {
                            HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
                            CONSOLE_SCREEN_BUFFER_INFO csbi;
                            WORD oldColor = 0;
                            if (hConsole != INVALID_HANDLE_VALUE && GetConsoleScreenBufferInfo(hConsole, &csbi)) {
                                oldColor = csbi.wAttributes;
                                SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY);
                            }
                            wprintf(L"[DEBUG] Closing suspicious process: %s\n", name.c_str());
                            OutputDebugStringW((L"[#StopSkids] Closing suspicious process: " + name + L"\n").c_str());
                            if (hConsole != INVALID_HANDLE_VALUE && oldColor)
                                SetConsoleTextAttribute(hConsole, oldColor);
                        } else {
                            DebugLog(L"[DDEBUG] Closing suspicious process: " + name);
                        }
                        CloseHandle(hProc);  
                    }  
                    ShowFakeCrashMessage(pe.szExeFile);  
                }  
            }  
        } while (Process32NextW(snap, &pe));  
    }  
    CloseHandle(snap);  

    if (g_TestMode && !found) {
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        CONSOLE_SCREEN_BUFFER_INFO csbi;
        WORD oldColor = 0;
        if (hConsole != INVALID_HANDLE_VALUE && GetConsoleScreenBufferInfo(hConsole, &csbi)) {
            oldColor = csbi.wAttributes;
            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        }
        wprintf(L"[DEBUG] No Debugging Programs Found\n");
        if (hConsole != INVALID_HANDLE_VALUE && oldColor)
            SetConsoleTextAttribute(hConsole, oldColor);
    }
}

void ScanAndCloseWindows() {
    static const std::vector<std::wstring> keys = {
        L"x64dbg", L"x32dbg", L"ida", L"ollydbg", L"windbg",
        L"cheat engine", L"process hacker", L"reshacker", L"system informer",
        L"pe-bear", L"detect it easy", L"api monitor", L"regshot",
        L"hollow hunter", L"pe studio", L"ghidra", L"radare2",
        L"binary ninja", L"hopper", L"wireshark", L"fiddler"
    };

    struct Ctx { const std::vector<std::wstring>* keys; } ctx{ &keys };

    EnumWindows([](HWND hwnd, LPARAM p) -> BOOL {
        auto& keys = *reinterpret_cast<Ctx*>(p)->keys;
        wchar_t buf[256] = {};
        GetWindowTextW(hwnd, buf, _countof(buf));
        std::wstring title = buf;
        std::wstring lower = ToLower(title);
        for (auto& k : keys) {
            if (lower.find(k) != std::wstring::npos) {
                ShowFakeCrashMessage(title);
                PostMessageW(hwnd, WM_CLOSE, 0, 0);
                break;
            }
        }
        return TRUE;
        }, (LPARAM)&ctx);
}

void ShowAndExit(const wchar_t* reason) {
    MessageBoxW(NULL, reason, L"#StopSkids", MB_ICONERROR | MB_OK);
    ExitProcess(1);
}

void RunAntiDebugLoop() {
    if (!g_TestMode) {
        if (auto hwnd = GetConsoleWindow())
            ShowWindow(hwnd, SW_HIDE);
    }
    else {
        DebugLog(L"Console visibility preserved in test mode.");
    }

    int cycleCount = 0;
    DebugLog(L"Anti-debug loop started.");

    while (true) {
        DebugLog(L"--- Cycle " + std::to_wstring(cycleCount) + L" ---");

        if (CheckBasicDebugging()) {
            DebugLog(L"Debugger detected: Basic check");
            ShowAndExit(L"Debugger detected (Basic)");
        }

        if (CheckNtQueryInfo()) {
            DebugLog(L"Debugger detected: NtQueryInformationProcess");
            ShowAndExit(L"Debugger detected (NtQueryInformationProcess)");
        }

        if (CheckOutputDebugString()) {
            DebugLog(L"Debugger detected: OutputDebugString trap");
            ShowAndExit(L"Debugger detected (OutputDebugStringTrap)");
        }

        if (CheckHardwareBreakpoints()) {
            DebugLog(L"Debugger detected: Hardware breakpoints");
            ShowAndExit(L"Hardware breakpoints detected");
        }

        if (cycleCount % 10 == 0) {
            DebugLog(L"Running execution timing check...");
            if (CheckExecutionTiming()) {
                DebugLog(L"Timing anomaly detected.");
                ShowAndExit(L"Execution timing anomaly detected");
            }
            else {
                DebugLog(L"Timing check passed.");
            }
        }

        if (cycleCount % 20 == 0) {
            DebugLog(L"Running virtual machine detection...");
            if (CheckVirtualMachine()) {
                DebugLog(L"VM environment detected.");
                ShowAndExit(L"Virtual environment detected");
            }
            else {
                DebugLog(L"VM check passed.");
            }
        }

        DebugLog(L"Scanning for blacklisted processes...");
        ScanAndKillProcesses();

        DebugLog(L"Scanning for blacklisted windows...");
        ScanAndCloseWindows();

        cycleCount++;
        std::this_thread::sleep_for(std::chrono::seconds(2));
    }
}

SERVICE_STATUS        g_ServiceStatus = {};
SERVICE_STATUS_HANDLE g_StatusHandle = nullptr;
HANDLE                g_StopEvent = INVALID_HANDLE_VALUE;

void WINAPI ServiceCtrlHandler(DWORD CtrlCode) {
    if (CtrlCode == SERVICE_CONTROL_STOP || CtrlCode == SERVICE_CONTROL_SHUTDOWN) {
        g_ServiceStatus.dwCurrentState = SERVICE_STOP_PENDING;
        SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
        SetEvent(g_StopEvent);
    }
}

void WINAPI ServiceMain(DWORD argc, LPWSTR* argv) {
    g_StatusHandle = RegisterServiceCtrlHandler(L"#StopSkids", ServiceCtrlHandler);
    if (!g_StatusHandle) return;

    g_ServiceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    g_ServiceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;
    g_ServiceStatus.dwCurrentState = SERVICE_START_PENDING;
    SetServiceStatus(g_StatusHandle, &g_ServiceStatus);

    g_StopEvent = CreateEvent(nullptr, TRUE, FALSE, nullptr);

    g_ServiceStatus.dwCurrentState = SERVICE_RUNNING;
    SetServiceStatus(g_StatusHandle, &g_ServiceStatus);

    RunAntiDebugLoop();

    WaitForSingleObject(g_StopEvent, INFINITE);

    g_ServiceStatus.dwCurrentState = SERVICE_STOPPED;
    SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
}

int wmain(int argc, wchar_t* argv[]) {
    if (argc > 1 && wcscmp(argv[1], L"--test") == 0) {
        g_TestMode = true;
        DebugLog(L"Running in TEST mode...");
        RunAntiDebugLoop();
        return 0;
    }

    SERVICE_TABLE_ENTRYW table[] = {
        { (LPWSTR)L"#StopSkids", ServiceMain },
        { nullptr, nullptr }
    };
    StartServiceCtrlDispatcherW(table);
    return 0;
}
